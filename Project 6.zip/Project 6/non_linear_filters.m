clc;
clear all;
close all;
img = imread('lena512.dib.bmp');
img = img(:,:,1);
%%
gauss_img = imnoise(img,'gaussian',0,0.01);
poisson_img = imnoise(img,'poisson');
snp_img = imnoise(img,'salt & pepper',0.05);
speckle_img = imnoise(img,'speckle',0.04);
%%
figure(1)
imshow(img); title('Orignal Image');
figure(2)
subplot(2,2,1)
imshow(uint8(gauss_img)); title('Gaussian Noise Img');
subplot(2,2,2)
imshow(uint8(poisson_img)); title('Poisson Noise Img');
subplot(2,2,3)
imshow(uint8(snp_img)); title('Salt & Pepper Noise Img');
subplot(2,2,4)
imshow(uint8(speckle_img)); title('Speckle Noise Img');

g_arth_mean = nlfilter(gauss_img,[3 3],@am_filter);
p_arth_mean = nlfilter(poisson_img,[3 3],@am_filter);
snp_arth_mean = nlfilter(snp_img,[3 3],@am_filter);
speckle_arth_mean = nlfilter(speckle_img,[3 3],@am_filter);
figure;
subplot(2,2,1)
imshow(uint8(g_arth_mean));
title('Gaussian Noise Arithmetic Mean');
subplot(2,2,2)
imshow(uint8(p_arth_mean));
title('Poisson Noise Arithmetic Mean');
subplot(2,2,3)
imshow(uint8(snp_arth_mean));
title('Salt & Pepper Noise Arithmetic Mean');
subplot(2,2,4)
imshow(uint8(speckle_arth_mean));
title('Speckle Noise Arithmetic Mean');

%%
%% Geometric Mean
F = @(x) gm_filter(x(:));
g_g_mean = nlfilter(double(gauss_img),[3 3],F);
p_g_mean = nlfilter(double(poisson_img),[3 3],F);
snp_g_mean = nlfilter(double(snp_img),[3 3],F);
s_g_mean = nlfilter(double(speckle_img),[3 3],F);
figure;
subplot(2,2,1)
imshow(uint8(g_g_mean)); title('gaussian noise geometric mean');
subplot(2,2,2)
imshow(uint8(p_g_mean)); title('poisson noise geometric mean');
subplot(2,2,3)
imshow(uint8(snp_g_mean)); title('salt & pepper noise geometric mean');
subplot(2,2,4)
imshow(uint8(s_g_mean)); title('speckle noise geometric mean');

% % Median Filter
% g_median = medfilt2(gauss_img);
% p_median = medfilt2(poisson_img);
% snp_median = medfilt2(snp_img);
% s_median = medfilt2(speckle_img);
% figure;
% subplot(2,2,1)
% imshow(uint8(g_median)); title('Gaussian Noise Median Filter');
% subplot(2,2,2)
% imshow(uint8(p_median)); title('Poisson Noise Median Filter');
% subplot(2,2,3)
% imshow(uint8(snp_median)); title('S & P Noise Median Filter');
% subplot(2,2,4)
% imshow(uint8(s_median)); title('Speckle Noise Median Filter');
% % Min Filter
% g_min = ordfilt2(gauss_img,1,ones(3,3));
% p_min = ordfilt2(poisson_img,1,ones(3,3));
% snp_min = ordfilt2(snp_img,1,ones(3,3));
% s_min = ordfilt2(speckle_img,1,ones(3,3));
% figure;
% subplot(2,2,1)
% imshow(uint8(g_min)); title('Gaussian Noise Min Filter');
% subplot(2,2,2)
% imshow(uint8(p_min)); title('Poisson Noise Min Filter');
% subplot(2,2,3)
% imshow(uint8(snp_min)); title('Salt & Pepper Noise Min filter');
% subplot(2,2,4)
% imshow(uint8(s_min)); title('Speckle Noise Min Filter');
% % Max Filter
% g_max = ordfilt2(gauss_img,9,ones(3,3));
% p_max = ordfilt2(poisson_img,9,ones(3,3));
% snp_max = ordfilt2(snp_img,9,ones(3,3));
% s_max = ordfilt2(speckle_img,9,ones(3,3));
% figure;
% subplot(2,2,1)
% imshow(uint8(g_max)); title('Gaussian Noise Max Filter');
% subplot(2,2,2)
% imshow(uint8(p_max)); title('Poisson Noise Max Filter');
% subplot(2,2,3)
% imshow(uint8(snp_max)); title('Salt & Pepper Noise Max filter');
% subplot(2,2,4)
% imshow(uint8(s_max)); title('Speckle Noise Max Filter');
% % Alphatrimmed Filter
% F = @(x) a_trim_filter(x(:));
% g_alpha = nlfilter(double(gauss_img),[3 3],F);
% p_alpha = nlfilter(double(poisson_img),[3 3],F);
% snp_alpha = nlfilter(double(snp_img),[3 3],F);
% s_alpha = nlfilter(double(speckle_img),[3 3],F);
% figure;
% subplot(2,2,1)
% imshow(uint8(g_alpha)); title('Gaussian Noise Alphatrimmed Mean');
% subplot(2,2,2)
% imshow(uint8(p_alpha)); title('Poisson Noise Alphatrimmed Mean');
% subplot(2,2,3)
% imshow(uint8(snp_alpha)); title('Salt & Pepper Noise Alphatrimmed Mean');
% subplot(2,2,4)
% imshow(uint8(s_alpha)); title('Speckle Noise Alphatrimmed Mean');
% % Mid-point Filter
% F = @(x) mid_filter(x(:));
% g_midpt = nlfilter(double(gauss_img),[3 3],F);
% p_midpt = nlfilter(double(poisson_img),[3 3],F);
% snp_midpt = nlfilter(double(snp_img),[3 3],F);
% s_midpt = nlfilter(double(speckle_img),[3 3],F);
% figure;
% subplot(2,2,1)
% imshow(uint8(g_midpt)); title('Gaussian Noise Mid-Point Filter');
% subplot(2,2,2)
% imshow(uint8(p_midpt)); title('Poisson Noise Mid-Point Filter');
% subplot(2,2,3)
% imshow(uint8(snp_midpt)); title('Salt & Pepper Noise Mid-Point Filter');
% subplot(2,2,4)
% imshow(uint8(s_midpt)); title('Speckle Noise Mid-Point Filter');