function mean = gm_filter(img)
[m,n] = size(img);
p = 0;Q = 1;
for i=1:m
for j=1:n
p = p*img(i,j);
end
end
mean = p^(1/m*n);